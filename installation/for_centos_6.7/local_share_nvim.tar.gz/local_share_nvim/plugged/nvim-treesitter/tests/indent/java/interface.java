public interface Foo {
}
