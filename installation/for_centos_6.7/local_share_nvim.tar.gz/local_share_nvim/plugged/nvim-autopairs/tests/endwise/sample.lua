local M={}

M.autopairs_bs = function(rules)
    for _, rule in pairs(rules) do

        if rule.start_pair then
end


    if rule.start_pair then

        end



    end
end
return M
