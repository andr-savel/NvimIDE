function test(a, b, c, d, e)
    vcat(a,
         b,
         c,
         d,
         e)

    vcat(
        a,
        b,
        c,
        d,
        e
    )
end
