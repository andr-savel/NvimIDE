void test() {
  try{
  } catch(e) {
  }
}

// Issue #4632
class Test {
  void test(){
    try {
    }
  }
}
