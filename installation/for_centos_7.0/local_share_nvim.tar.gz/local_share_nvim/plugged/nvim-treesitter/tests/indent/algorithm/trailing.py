class x: # Ignore comment

class y: 
    def z(): # Ignore comment

class t:    
