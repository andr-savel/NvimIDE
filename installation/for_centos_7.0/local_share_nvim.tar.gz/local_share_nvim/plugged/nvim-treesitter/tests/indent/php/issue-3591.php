<?php

function test() {
    $array = [
}
