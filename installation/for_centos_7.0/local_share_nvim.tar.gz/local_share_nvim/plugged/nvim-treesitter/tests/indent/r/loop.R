x <- 1

while (x < 10) {
  x <- x + 1
  break
}

for (i in 1:3) {
  x <- x + 1
}

repeat {
  x <- x + 1
  if (x > 100) {
    break
  }
}
