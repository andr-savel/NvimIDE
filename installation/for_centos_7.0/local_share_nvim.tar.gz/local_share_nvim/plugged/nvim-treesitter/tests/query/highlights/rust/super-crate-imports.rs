use crate::a;
//  ^ namespace
//  ^ !keyword
use crate::{b, c};
//  ^ namespace
//  ^ !keyword
use super::a;
//  ^ namespace
//  ^ !keyword
use super::{b, c};
//  ^ namespace
//  ^ !keyword
