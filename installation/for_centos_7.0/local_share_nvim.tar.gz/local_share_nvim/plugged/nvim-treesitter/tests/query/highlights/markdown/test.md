# H1
<!-- <- punctuation.special -->

## H2
<!-- <- punctuation.special -->

- Item 1
- Item 2
<!-- <- punctuation.special -->

1. Item 1
2. Item 2
<!-- <- punctuation.special -->

----![image_description](https://example.com/image.jpg "awesome image title")
<!--  ^ text.reference                                                    -->
<!--                              ^ text.uri                              -->
<!--                                                      ^ text.literal  -->
<!--^ punctuation.delimiter                                               -->
<!-- ^ punctuation.delimiter                                              -->
<!--                                                                      //TODO: currently disabled punctuation.delimiter -->

[link_text](#local_reference "link go brr...")
<!-- ^ text.reference                                                     -->
<!--                 ^ text.uri                                           -->
<!--                            ^ text.literal                            -->
<!-- <- punctuation.delimiter                                             -->
<!--                                                                      //TODO: currently disabled punctuation.delimiter -->
