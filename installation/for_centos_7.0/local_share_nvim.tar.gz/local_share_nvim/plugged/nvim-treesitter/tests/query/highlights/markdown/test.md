# H1
<!-- <- text.title.1.marker -->

## H2
<!-- <- text.title.2.marker -->

- Item 1
- Item 2
<!-- <- punctuation.special -->

1. Item 1
2. Item 2
<!-- <- punctuation.special -->

----![image_description](https://example.com/image.jpg "awesome image title")
<!--  ^ text.reference                                                    -->
<!--                              ^ text.uri                              -->
<!--                                                      ^ text.literal  -->
<!--^ punctuation.special                                                 -->
<!-- ^ punctuation.bracket                                                -->
<!--                    ^ punctuation.bracket                             -->

[link_text](#local_reference "link go brr...")
<!-- ^ text.reference                                                     -->
<!--                 ^ text.uri                                           -->
<!--                            ^ text.literal                            -->
<!-- <- punctuation.bracket                                               -->
<!--       ^ punctuation.bracket                                          -->
